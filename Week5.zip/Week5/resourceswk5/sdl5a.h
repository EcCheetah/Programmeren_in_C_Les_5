#ifndef sdl5a_h
#define sdl5a_h

extern SDL_Window *window;
extern SDL_Renderer *renderer;

void handle_key(SDL_KeyboardEvent *keyevent, keystate updown, player *tha_playa);
void make_bullet_casing(player *tha_playa);
void show_bullet_route();
void init_muzzleflash(player *tha_playa, muzzleflash *tha_flash);
void draw_muzzleflash(muzzleflash *tha_flash);
void load_texture_blorp(player *tha_playa);
void load_texture_zombie(player *tha_playa, zombie *tha_zombo);
void process_input(player *tha_playa, mouse *tha_mouse, muzzleflash *tha_flash);
void update_player(player *tha_playa, mouse *tha_mouse);
void proper_shutdown(void);
SDL_Texture *load_texture(char *filename);

#endif

