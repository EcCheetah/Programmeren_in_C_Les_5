#ifndef common_h
#define common_h

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h> // for IMG_Init and IMG_LoadTexture
#include <math.h> // for atan() function

#define SCREEN_WIDTH				1800
#define SCREEN_HEIGHT				1000
#define PI					3.14159265358979323846

// Move this much pixels every frame a move is detected:
#define PLAYER_MAX_SPEED			6.0f

// AFTER a movement-key is released, reduce the movement speed for 
// every consecutive frame by (1.0 - this amount):
#define PLAYER_DECELERATION			0.25f

// Make A Define That Will Set The Amount Of Bullets On Screen//
#define BULLET_MAGAZINE				50
#define BULLET_ACCELERATION			20

// A mouse structure holds mousepointer coords & a pointer texture:
typedef struct _mouse_ {
       	int x;
 	int y;
  	SDL_Texture *txtr_reticle;
} mouse;

// Our Own Struct To Make Bullets //
typedef struct _bullet_ {
 	int bullet_casing;
  	double x;
  	double y;

  	SDL_Texture *txtr_bullet;
  
  	double angle;
} bullet;

// all states for blorp //
typedef enum _playerstate_ {
  	IDLE = 0,
  	WALKING = 1,
  	SHOOTING = 2
} playerstate;

// Added: speed in both directions and rotation angle:
typedef struct _player_ {
  	int x;
  	int y;
  	float speed_x;
  	float speed_y;
  	int up;
  	int down;
  	int left;
  	int right;
  	float angle;
  
  	// for the textures of blorp //
  	SDL_Texture *txtr_body;
  	SDL_Texture *txtr_feet;
  	int location_idle_texture; 
  	int location_moving_texture;
  	playerstate state;
} player;

typedef struct _zombie_ {
	int x;
	int y;
	float angle;
	SDL_Texture *txtr_zombie;
	int location_idle_texture;
} zombie;

typedef enum _visible_ {
	NO = 0,
	YES = 1
} visible;

typedef struct _muzzleflash_ {
	int x;
	int y;
	double angle;
	SDL_Texture *txtr_flash;
	visible visible_state; //Show or dont show the muzzleflash
} muzzleflash;

typedef enum _keystate_ {
  	UP = 0,
  	DOWN = 1
} keystate;

#endif
