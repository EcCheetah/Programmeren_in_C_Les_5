#ifndef calc_h
#define calc_h

float get_angle(int x1, int y1, int x2, int y2, SDL_Texture *txtr); 

#endif
